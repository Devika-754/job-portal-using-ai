import React from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import FeatureCard from "./components/FeatureCard";
import "./App.css";

function App(){
return(
<div>
<Navbar/>
<Hero/>
<div className="features">
<FeatureCard title="Design" text="Create UI from Adobe XD designs"/>
<FeatureCard title="Development" text="Convert layouts into React"/>
<FeatureCard title="Deployment" text="Deploy using Netlify"/>
</div>
</div>
);
}

export default App;