import React from "react";

function Hero(){
return(
<div className="hero">
<h1>Convert Adobe XD Design to React</h1>
<p>Build responsive UI using React components</p>
<button className="hero-btn">Get Started</button>
</div>
);
}

export default Hero;