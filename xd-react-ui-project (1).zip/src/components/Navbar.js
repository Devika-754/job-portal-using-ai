import React from "react";

function Navbar(){
return(
<nav className="navbar">
<h2>ReactUI</h2>
<ul className="nav-links">
<li>Home</li>
<li>Features</li>
<li>About</li>
<li>Contact</li>
</ul>
</nav>
);
}

export default Navbar;